package az.afterg.chatapp;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import az.afterg.chatapp.Adapter.FriendListAdapter;
import az.afterg.chatapp.Constants.PC;
import az.afterg.chatapp.Data.FriendsListData;

import com.ansoft.chatapp.R;
import com.parse.ParseUser;

import java.util.ArrayList;
import java.util.List;

public class FriendsFragment extends Fragment {

    ListView list;
    ParseUser currentUser;
    FriendListAdapter adapter;
    List<String> friendslist;
    ArrayList<FriendsListData> data;


    public FriendsFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
    }


    public void getFriends() {
        for (int i = 0; i < friendslist.size(); i++) {
            FriendsListData d = new FriendsListData();
            d.setUserId(friendslist.get(i).toString());
            data.add(d);
        }
        adapter = new FriendListAdapter(data, getActivity());
        list.setAdapter(adapter);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View cv = inflater.inflate(R.layout.fragment_friends, container, false);
        list = (ListView) cv.findViewById(R.id.listView);
        currentUser = ParseUser.getCurrentUser();
        data = new ArrayList<>();
        friendslist = currentUser.getList(PC.KEY_FRIENDS_ID);
        if (friendslist!=null){
        getFriends();}
        return cv;
    }


}
